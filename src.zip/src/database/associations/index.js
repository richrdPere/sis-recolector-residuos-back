module.exports = (db) => {

    // - Auth
    require("./auth.associations")(db);

    // - Vehículos
    require("./vehiculos.associations")(db);

    // - Personal operativo
    require("./personal.associations")(db);

    // - Rutas y zonas
    require("./rutas.associations")(db);

    // - Programaciones
    require("./programaciones.associations")(db);

    // - Recorridos
    require('./recorridos.associations')(db);

    // - Recoleccion
    require("./recoleccion.associations")(db);

    // - Incidentes
    require("./incidencias.associations")(db);

    // - Notificaciones
    require("./notificaciones.associations")(db);

    // - Ciudadanos
    require("./ciudadanos.associations")(db);

    // - Codigos QR 
    require("./codigos_qr.associations")(db);

    // - Reportes y Auditoria
    require("./reportes.associations")(db);
}