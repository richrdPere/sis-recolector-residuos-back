const express = require("express");
const cors = require("cors");
require("dotenv").config();

// Swagger - Documentación de la API.
const swaggerUi = require('swagger-ui-express');
const openapiDocument = require('./docs/openapi.js');

const path = require("path");
const fs = require("fs");

// Firebase
const { initializeFirebaseAdmin } = require('./config/firebase-admin');

// Utils
const crearAdminPorDefecto = require("./utils/initAdmin");
const crearRolesPorDefecto = require("./utils/initRoles");

// Routes
const router = require("./routes/index");

// Models
const db = require("./database/models");

const app = express();

// ==========================================================
// DOCUMENTACIÓN REST/API
// ==========================================================

// Especificación OpenAPI en JSON.
app.get('/openapi.json', (_req, res) => {
  res.json(openapiDocument);
});

// Interfaz Swagger UI.
app.use(
  '/api-docs',
  swaggerUi.serve,
  swaggerUi.setup(openapiDocument, {
    customSiteTitle: 'Catálogo REST/API - Recolección de Residuos',

    swaggerOptions: {
      docExpansion: 'list',
      displayRequestDuration: true,
      validatorUrl: null,
    },
  }),
);

// ==========================================================
// CONFIGURACIÓN GENERAL
// ==========================================================

app.use(cors());

app.use(express.json({
  limit: "10mb",
})
);

app.use(express.urlencoded({
  extended: true,
  limit: "10mb",
})
);

// ==========================================================
// DIRECTORIO DE ARCHIVOS
// ==========================================================

/*
 * DESARROLLO:
 *
 * Si UPLOADS_DIR no existe en .env:
 *
 * backend/uploads
 *
 *
 * PRODUCCIÓN:
 *
 * UPLOADS_DIR=/var/www/aryoria/uploads
 */

const uploadsRoot = process.env.UPLOADS_DIR ||
  path.join(
    __dirname,
    "../../../uploads"
  );

// ==========================================================
// CREAR DIRECTORIO SI NO EXISTE
// ==========================================================
if (!fs.existsSync(uploadsRoot)) {
  fs.mkdirSync(
    uploadsRoot,
    {
      recursive: true,
    }
  );
}

// ==========================================================
// ARCHIVOS ESTÁTICOS
// ==========================================================
app.use("/uploads", express.static(uploadsRoot, { maxAge: "30d", immutable: false, }));

// ==========================================================
// RUTAS PRINCIPALES DE LA API
// ==========================================================
app.use("/api", router);


// ==========================================================
// MANEJADOR GLOBAL DE ERRORES
// Debe ubicarse después de las rutas.
// ==========================================================
app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  const codigo = Number(err.statusCode ?? err.status);

  const statusCode =
    Number.isInteger(codigo) && codigo >= 400 && codigo <= 599
      ? codigo
      : 500;

  console.error("❌ Error en la API:", err);

  return res.status(statusCode).json({
    success: false,
    message:
      statusCode < 500
        ? err.message || "No se pudo completar la operación."
        : "Ocurrió un error interno del servidor.",
  });
});
// ==========================================================
// FUNCIÓN DE INICIO
// ==========================================================

const startServer = async () => {
  try {

    // MYSQL
    await db.sequelize.authenticate();

    console.log("✅ Conexión a MySQL establecida");

    // MODELOS
    await db.sequelize.sync({ alter: false });

    console.log("📦 Modelos sincronizados");

    // FIREBASE
    initializeFirebaseAdmin();

    // ROLES
    await crearRolesPorDefecto();

    // ADMIN
    await crearAdminPorDefecto();

    // UPLOADS
    // console.log(
    //   `📁 Uploads disponibles en: ${uploadsRoot}`
    // );
  } catch (error) {
    console.error("❌ Error al iniciar servidor:", error);
    throw error;
  }
};

app.initialize = startServer;

module.exports = app;

