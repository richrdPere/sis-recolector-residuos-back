const path = require('node:path');
const fs = require('node:fs/promises');

const AppError = require('../../../utils/app-error');

const getIncidenciaArchivoService = require('../services/get-incidencia-archivo.service');

const { obtenerMetadata } = require('../utils/incidencias-controller.utils');

// Misma base que utiliza incidencia-upload.middleware.js.
const uploadsRoot = path.resolve(process.cwd(), 'uploads');

const incidenciaArchivoContenidoController = async (req, res, next) => {
  try {
    // Este service valida usuario, pertenencia y autorización.
    const archivo = await getIncidenciaArchivoService(
      req.params.id,
      req.params.idArchivo,
      obtenerMetadata(req),
    );

    if (archivo.almacenamiento !== 'LOCAL') {
      throw new AppError(
        'El almacenamiento de esta evidencia no está disponible.',
        409,
        'INCIDENCIA_STORAGE_UNAVAILABLE',
      );
    }

    const rutaGuardada = archivo.ruta_archivo;

    if (
      typeof rutaGuardada !== 'string' ||
      !rutaGuardada.trim() ||
      path.isAbsolute(rutaGuardada)
    ) {
      throw new AppError(
        'La ubicación de la evidencia no es válida.',
        409,
        'INCIDENCIA_FILE_PATH_INVALID',
      );
    }

    let raiz;
    let ruta;

    try {
      // realpath también permite comprobar enlaces simbólicos.
      raiz = await fs.realpath(
        path.join(uploadsRoot, 'incidencias'),
      );

      ruta = await fs.realpath(
        path.resolve(uploadsRoot, rutaGuardada),
      );
    } catch (error) {
      if (['ENOENT', 'ENOTDIR'].includes(error.code)) {
        throw new AppError(
          'La evidencia ya no está disponible en el servidor.',
          404,
          'INCIDENCIA_FILE_NOT_FOUND',
        );
      }

      throw error;
    }

    const relativa = path.relative(raiz, ruta);

    if (
      !relativa ||
      relativa === '..' ||
      relativa.startsWith(`..${path.sep}`) ||
      path.isAbsolute(relativa)
    ) {
      throw new AppError(
        'La ubicación de la evidencia no está permitida.',
        403,
        'INCIDENCIA_FILE_PATH_FORBIDDEN',
      );
    }

    const stat = await fs.stat(ruta);

    if (!stat.isFile()) {
      throw new AppError(
        'La evidencia no está disponible.',
        404,
        'INCIDENCIA_FILE_NOT_FOUND',
      );
    }

    res.set({
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    });

    return res.download(
      ruta,
      path.basename(archivo.nombre_original || 'evidencia'),
      (error) => {
        if (error) next(error);
      },
    );
  } catch (error) {
    next(error);
  }
};

module.exports = incidenciaArchivoContenidoController;