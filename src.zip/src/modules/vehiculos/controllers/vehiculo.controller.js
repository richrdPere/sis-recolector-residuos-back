const {
  createVehiculoService,
  getVehiculosPaginadoService,
  getVehiculoByIdService,
  updateVehiculoService,
  changeEstadoVehiculoService,
  deleteVehiculoService,
  getLastCodigoVehiculoService,
  getVehiculosSelectorService,
  changeEstadoOperativoVehiculoService,
} = require('../services');

const { cambiarFoto } = require('../services/vehiculo-foto.service');

const { limpiarTemporal } = require('../../../middlewares/vehiculo-foto-upload.middleware');

/*
|--------------------------------------------------------------------------
| 1. Crear vehículo
|--------------------------------------------------------------------------
*/
const createVehiculoController = async (req, res, next) => {
  try {
    const vehiculo = await createVehiculoService(req.body);

    return res.status(201).json({
      success: true,
      message: 'Vehículo registrado correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 2. Listar vehículos + Paginado
|--------------------------------------------------------------------------
*/
const getVehiculosPaginadoController = async (req, res, next) => {
  try {
    const result = await getVehiculosPaginadoService({
      page: req.query.page,
      limit: req.query.limit,
      search: req.query.search,
      estado: req.query.estado,
      estado_operativo: req.query.estado_operativo,
      tipo_vehiculo: req.query.tipo_vehiculo,
    });

    return res.status(200).json({
      success: true,
      message: 'Vehículos obtenidos correctamente.',
      data: result,
      // pagination: result.pagination,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 3. Obtener vehículo
|--------------------------------------------------------------------------
*/
const getVehiculoByIdController = async (req, res, next) => {
  try {
    const vehiculo =
      await getVehiculoByIdService(
        req.params.id,
      );

    return res.status(200).json({
      success: true,
      message:
        'Vehículo obtenido correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 4. Actualizar vehículo
|--------------------------------------------------------------------------
*/
const updateVehiculoController = async (req, res, next) => {
  try {
    const vehiculo =
      await updateVehiculoService(
        req.params.id,
        req.body,
      );

    return res.status(200).json({
      success: true,
      message:
        'Vehículo actualizado correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 5. Activar o desactivar vehículo
|--------------------------------------------------------------------------
*/
const changeEstadoVehiculoController = async (req, res, next) => {
  try {
    const vehiculo =
      await changeEstadoVehiculoService({
        id_vehiculo: req.params.id,
        estado: req.body.estado,
      });

    return res.status(200).json({
      success: true,
      message:
        'Estado del vehículo actualizado correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 6. Eliminar vehículo
|--------------------------------------------------------------------------
*/
const deleteVehiculoController = async (req, res, next) => {
  try {
    const result = await deleteVehiculoService(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'Vehículo eliminado correctamente.',
      data: result,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 7. Obtener ultimo codigo de vehículo
|--------------------------------------------------------------------------
*/
const getLastCodigoVehiculoController = async (req, res, next) => {
  try {
    const codigo = await getLastCodigoVehiculoService();

    return res.status(200).json({
      success: true,
      message: 'Código de vehículo obtenido correctamente.',
      data: { codigo },
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 8. Obtener ultimo codigo de vehículo
|--------------------------------------------------------------------------
*/
const getVehiculosSelectorController = async (req, res, next) => {
  try {
    const data = await getVehiculosSelectorService({ search: req.query.search, });

    return res.status(200).json({
      success: true,
      message: 'Selector de vehículos obtenido correctamente.',
      data: data,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 9. Subir foto - vehiculo
|--------------------------------------------------------------------------
*/
const subirFotoVehiculoController = async (req, res, next) => {
  try {
    const vehiculo = await cambiarFoto(
      req.params.id,
      req.file,
    );

    return res.status(200).json({
      success: true,
      message: 'Fotografía guardada correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  } finally {
    await limpiarTemporal(req);
  }
};
/*
|--------------------------------------------------------------------------
| 10. Eliminar foto - vehiculo
|--------------------------------------------------------------------------
*/
const eliminarFotoVehiculoController = async (req, res, next) => {
  try {
    const vehiculo = await cambiarFoto(
      req.params.id,
      null,
      true,
    );

    return res.status(200).json({
      success: true,
      message: 'Fotografía eliminada correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};
/*
|--------------------------------------------------------------------------
| 11. Cambiar estado operativo
|--------------------------------------------------------------------------
*/
const changeEstadoOperativoVehiculoController = async (req, res, next) => {
  try {
    const vehiculo = await changeEstadoOperativoVehiculoService(
      req.params.id,
      req.body,
    );

    return res.status(200).json({
      success: true,
      message: 'Estado operativo del vehículo actualizado correctamente.',
      data: vehiculo,
    });
  } catch (error) {
    next(error);
  }
};


module.exports = {
  createVehiculoController,
  getVehiculosPaginadoController,
  getVehiculoByIdController,
  updateVehiculoController,
  changeEstadoVehiculoController,
  deleteVehiculoController,
  getLastCodigoVehiculoController,
  getVehiculosSelectorController,
  subirFotoVehiculoController,
  eliminarFotoVehiculoController,
  changeEstadoOperativoVehiculoController,
};