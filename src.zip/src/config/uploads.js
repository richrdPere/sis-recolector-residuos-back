const path = require('node:path');

const uploadsRoot = path.resolve(
  process.env.UPLOADS_DIR ||
  path.join(__dirname, '../../uploads'),
);

// Fuera del directorio publicado mediante express.static.
const tempRoot = path.join(
  path.dirname(uploadsRoot),
  '.recoleccion-upload-tmp',
);

module.exports = {
  uploadsRoot,
  tempRoot,
};